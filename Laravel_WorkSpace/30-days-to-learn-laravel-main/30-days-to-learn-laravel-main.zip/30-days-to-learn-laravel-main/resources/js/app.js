import './bootstrap';
import "../css/app.css";

// alert('hello from the JS');
